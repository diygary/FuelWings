FuelWings
_________

(IMPORTANT: IF YOU'VE INSTALLED VERSIONS PRIOR TO V1.4, REPLACE YOUR "Wings" FOLDER INSIDE (KSP_Folder)\GameData\Squad\SPP , WITH THE ORIGINAL STOCK "WINGS" FOLDER! IT IS PROVIDED IN "if_needed_(readme).zip")
Fuel resources added to stock, B9 wings, and B9 procedural by Tortoise  (IRC name: Tortoise767, Youtube:Tortoise010, Other: BeautiCode). Credits to azza276 for B9 support, Credits to Critter79606 for compatibility fixes)
This 'addon' allows the SP+ (now integrated with stock since 0.25) wings to contain fuel.
The intention of this is to allow better weight & balance, reduce craft length, and provide more aesthetic pleasure.
See the "FW_FuelValues" file for the fuel max values of the wings.
All wing fuel values are set to 0 by default, you must right-click the wings and add fuel if you'd like.
Supports all stock fuels

INSTALLATION:
(1)Drop all folders inside of GameData folder into (KSP_Folder)\GameData\
(2)Drop ModuleManager.2.5.1.dll into (KSP_Folder)\GameData\
(3)Startup KSP and enjoy!

Startup your game and enjoy!
All rights reserved.

Changelog
---------
v4 (11/08/2020)
*Updated for 1.10.x*
*Resolved conflicts that occur when multiple fuel mods are installed (FSFuelSwitch, Interstellar, ConfigurableContainers, etc). FW takes priority if possible*
*Replaced ProceduralWings support for B9 ProceduralWings*
*Added ability for maximum fuel value to scale up/down as procedural wing changes in size*

v3.2f (12/23/2018)
*Updated for 1.5.x*
v3.2e (01/01/2018)
"FuelWings updated for 1.4.1"

v3.2d (07/03/2017)
"added Updated Modular fuel tanks mod dependency."
"Fuel wings updated for 1.3"
v3.2c (04/1/2017)
*It's working again; Emergency update applied. Someone did not save the files as .cfg, breaking the entire mod.
v3.2b (03/31/2017)
*Linuxgurugamer caught & fixed some weird foreign characters in the mod configuration
v3.2 (03/9/2017)
FUELWINGS IS NOW MAINTAINED BY vardicd FOR THE TIMEBEING.
-Updated for KSP v1.2.2 & added support for more parts:
"added up to date Modular fuel tanks mod.
added fuel tank support for:
 swept wing
 Tail Connector A+B
 Small Nose Cone
 Aerodynamic Nose Cone
 Advanced Nose cone type A+B"


v3.15 (10/09/2016)
*Finalized work-around for issue causing craft(s) to be stuck in position upon launch
-small Swept Wing can no longer be fueled either

v3.1 (10/08/2016)
*Applied experimental fix to issue causing craft(s) to be stuck in position upon launch
-To fix this issue, support(fuel) for the following parts had to be removed:
Standard Canard
Advanced Canard
Tail Fin
FAT-455 Aeroplane Tail Fin
Big-S Spaceplane Tail Fin
-All of the parts listed are MOVING wing surfaces.

v3.0 (5/20/2016)
*Limited ProceduralDynamics support
*Tweaks & Updates

v2.95 (5/15/2016)
*Updated dependencies to latest version & removed ones no longer needed.

v2.9 (5/01/2016)
*Updated to support 1.1.2+

v2.8 (4/24/2016)
*Updated to support KSP v1.1.0+
*Discontinued support for FuelWings v1.4

v2.7 (12/4/2015)
*Updated to support 1.0.5+

v2.5 (5/15/2015)
*Fixed crossfeed capability for new parts

v2.4 (5/14/2015)
*Updated to support 1.0+
*Added support for 6 new parts

v2.2 (1/19/15)
*Updated to support 0.90.0

v2.1 (11/24/14)
*Fixed some crossfeeding bugs in stock structural wings.

v2.0 (11/9/14) for KSP 0.25
*Now with B9 support thanks to azza276
*Fixed error in stock code

v1.8 (11/6/15) for KSP 0.25
*Major code revisions making file size much lower and increasing organization of code.
*Implemented ModularFuelTanks support which gives the ability to switch fuels in the editor.
*Nerfed maximum fuel values
*(Does not require initial selection of wings with LF or LF/LOX anymore. Just 1 FuelWings folder) Supports all stock fuels

v1.4 (10/22/14) for KSP 0.25
*No longer requires you to replace stock "Wings" folder, uses ModuleManager.
*Fixed some incorrect module values.

v1.2 (10/18/14) for KSP 0.25
*Now requires Crossfeed Enabler & Module Manager
*Does not need fuel lines to connect from wing to fuselage.
